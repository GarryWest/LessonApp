'use strict';

/**
 * @ngdoc function
 * @name lessonsApp.controller:DayCtrl
 * @description
 * # DayCtrl
 * Controller of the lessonsApp
 */
angular.module('lessonsApp')
  .controller('DayCtrl', function ($scope) {
    $scope.description = dayDetails[0];
  });
