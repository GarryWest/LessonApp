'use strict';

/**
 * @ngdoc overview
 * @name lessonsApp
 * @description
 * # lessonsApp
 *
 * Main module of the application.
 */
angular
  .module('lessonsApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'AppCtrl'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl'
      })
      .when('/day/:dayCode', {
        templateUrl: 'views/day.html',
        controller: 'DayCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  });

